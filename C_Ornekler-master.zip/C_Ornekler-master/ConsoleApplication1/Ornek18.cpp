


/*
#include <stdio.h>
#include <string.h>
int main()
{
	int enbuyuk;
	int d[10];
	d[0] = -30;
	d[1] = -39;
	d[2] = -23;
	d[3] = -33;
	d[4] = -39;
	d[5] = -303;
	d[6] = -3003;
	d[7] = -3356;
	d[8] = -100;
	d[9] = -358;

	enbuyuk = d[0]; //d[] i�indeki rakam k�yaslama amac�yla herhangi bir say�da olabilir
	//d[0]� baz alarak t�m diziyi onunla k�yaslar
	//enbuyuk i�ine atar
	//d[0]dan b�y�k olan varsa if ko�ulunda onu tutar
	for (int i = 0;i <= 9;i++)
	{
		if (enbuyuk < d[i])
		{
			enbuyuk = d[i];
		}
	}
	printf("sonuc = %d", enbuyuk);
	return 1;
}*/