

/*
//Ondal�kl� Yazma
#include <stdio.h>

int main() {
	double a = 5.6;
	double b = 0.8;
	double sonuc = a + b;

	printf("%.2f", sonuc);  //ondal�k say�lar� (float veya double) belirli bir noktadan sonra
                        // kesmek veya yuvarlamak i�in kullan�lan bir yer tu
	printf("\n"); //a�a�� sat�ra kayd�r�r
	printf("%f", sonuc); //%f=ondal�kl� say�lar (float veya double) i�in yer tutucu belirtir.
	return 1;
}*/