

/*/
//char �rne�i 2
#include <stdio.h>

int main() {
    char* isim; //* koyunca ramda limitsiz karakter acar
    isim = "Miray";
    char soyad[10] = "Durgun";
    char* il = "Istanbul";
    printf("%s\n", isim);
    printf("%s\n", soyad);
    printf("%s\n", il);

    return 1;
}
*/