
/*
//Toplama ��lemi
#include <stdio.h>

int main() { //c kodu main ile ba�lar
    int  a;
    int b;
    int snc;
    a = 5;
    b = 45;
    snc = b + a;
    printf("%d + %d = %d", a, b, snc); //printf ekrana yazd�r�r
    //%d, tamsay� girdisi i�in kullan�lan bi�imlendirme dizisidir
    return 1;
}*/