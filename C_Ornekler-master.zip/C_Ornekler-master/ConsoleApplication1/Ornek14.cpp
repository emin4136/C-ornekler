

/*
//c dilinde for d�ng�s�
#include <stdio.h>
#include <string.h>

int main() {
    int c;
    for (c = 1;c <= 10;c++) //10A kadar yazd�ran for d�ng�s�
    {
        printf("%d\n", c);
    }
    return 1;
}*/