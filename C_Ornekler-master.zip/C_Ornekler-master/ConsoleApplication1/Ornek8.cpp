
/*
//CLionda hatas�z �al���yor
//2 Boyutlu Diziler
//iki boyutlu dizi, verileri matrisler gibi d�zenlemek i�in kullan�l�r
//�ki boyutlu dizi, bir sat�r ve bir s�tun indeksi kullan�larak eri�ilebilen elemanlar i�eri
#include <stdio.h>
#include <string.h>

int main() {
	char stringArray[3][10]; //stringArray adl� bir 2 boyutlu karakter dizisi olu�turur
							// ve bu diziye �� farkl� isim atar.
	strcpy(stringArray[0], "Miray");
	strcpy(stringArray[1], "Umut");
	strcpy(stringArray[2], "Hilal");
	printf("%s", stringArray[1]);
	return 1;
}*/