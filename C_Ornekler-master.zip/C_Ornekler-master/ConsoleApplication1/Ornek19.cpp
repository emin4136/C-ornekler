

/*
//Rasgele say� �reten program

#include <stdio.h>
#include <stdlib.h>
#include <time.h>
int main() {
	int sayi;

	srand(time(NULL)); // her defas�nda fakl� say� �retebilmek i�in
	//rastgele say� �reticisinin ba�lang�� de�erini belirler
	//her saniye ba�ka de�er �retir

	sayi = rand();
	printf("Sayi = %d", sayi);
}
*/