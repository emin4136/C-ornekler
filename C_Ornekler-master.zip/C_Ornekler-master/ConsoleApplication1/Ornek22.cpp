

/*
* //CLion da hatas�z �al���yor
//kullan�c�dan al�nan sat�r say�s� kadar merdicen �eklinde say�lar� yazd�r�r
#include <stdio.h>
#include <conio.h>
int main(void)
{
    int i, n, j;
    printf("satir sayisi:");
    scanf("%d", &n);
    for (i = 1;i <= n;i++)
    {
        for (j = i;j >= 1;j--)
        {
            printf("%3d", i);
        }
        printf("\n");
    }
}
*/