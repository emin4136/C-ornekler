

/*
//char �rne�i
#include <stdio.h>
#include <string.h>

int main() {
    char* isim; //* koyunca ramda limitsiz karakter acar
    isim = "Miray";
    char soyad[10] = "Durgun"; //y�ld�z koyarsak [], [] koyarsak *  koyamay�z.
    char* il[255];
    strcpy(il, "Istanbul"); // strcpy= string fonksiyonudur
    printf("%s\n", isim);
    printf("%s\n", soyad);
    printf("%s\n", il);
    return 1;
}
*/