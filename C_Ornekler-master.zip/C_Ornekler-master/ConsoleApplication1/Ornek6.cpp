

/*

#include <stdio.h>
#include <string.h>

int main() {
	char karar = 'E';
	printf("%c", karar); //%c tek bir karakter (char) i�in yer tutucu
	return 1;
}*/