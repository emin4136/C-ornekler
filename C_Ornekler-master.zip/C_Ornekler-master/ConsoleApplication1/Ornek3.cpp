
//CLion Program�nda hatas�z �al���yor
/*
#include <stdio.h>

int main() {
    char* isim; //* koyunca ramda limitsiz karakter acar
    isim = "Miray";
    printf("%s", isim); //%s string i�in yer tutucu
    return 1;
}*/