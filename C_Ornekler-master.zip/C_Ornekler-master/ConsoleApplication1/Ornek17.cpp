
/*
//Fonksiyonlar - Alt Programlar
#include <stdio.h>
#include <string.h>

int topla(int a, int b)
{
    int sonuc;
    sonuc = a + b;
    return sonuc; //sonucu geri d�nd�r�r
}
int main()
{
    int s;
    s = topla(5, 55); //topla fonksiyonu burada kullan�l�r a i�ine 5 b i�ine 55 atan�r toplama i�lemi yap�l�r s ye atan�r
    printf("%d", s);
    return 1;
}*/