
/*
//�ARPIM TABLOSU �DEV�
//1den 10 a kadar olan say�lar�n �arp�m tablosu
#include <stdio.h>
#include <conio.h>
int main(void)
{
    int i,sonuc,j;
    printf("Carpim Tablosu \n");
    for(i=1;i<=10;i++)
    {
        for(j=1;j<=10;j++)
        {
           sonuc= i*j;
            printf("%d x %d =  %d\n",i,j,sonuc);
        }
        printf("\n");
    }
    return 1;
}*/