

/*
// Rasgele say� �reten program, 0 - 100 aras�nda
#include <stdio.h>
#include <stdlib.h>
#include <time.h>
int main() {
	int sayi;

	srand(time(NULL)); // her defas�nda fakl� say� �retebilmek i�in

	sayi = rand() % 100; //100e kadar �retir
	printf("Sayi = %d", sayi);
}*/