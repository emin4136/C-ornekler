

/*
//CLion'da hatas�z �al���yor
//kulan�c�dan istenen de�erler ile toplama i�lemi
#include <stdio.h>
#include <string.h>

int main() {
    int sayi1, sayi2, sonuc;
    printf("1. sayi giriniz:");
    scanf("%d", &sayi1);
    printf("2. sayi giriniz:");
    scanf("%d", &sayi2);
    sonuc = sayi1 + sayi2;

    printf("*******************\n1. sayi = %d\n2.sayi= %d\nsonuc= %d\n*******************", sayi1, sayi2, sonuc);
    return 1;
}*/