




/*
//fakt�riyel �rne�i
#include <stdio.h>
#include <string.h>

int main() {
    int i = 0;
    int sonuc = 1;
    for (i = 1;i <= 5;i++) //fakt�riyel �rne�i
    {
        sonuc *= i; //i her artt���nda kendinden �nceki say�y� tutar ve i'yi onun ile �arpar
        printf("%d\n", sonuc);
    }
    return 1;
}
*/