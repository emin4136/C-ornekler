

/*
//Dizi ile toplama
#include <stdio.h>

int main() {
    int d[10];
    int sonuc = 0;
    d[0] = 5;
    d[1] = 8;
    sonuc = d[0] + d[1];
    printf("%d", sonuc);
    return 1;
}*/